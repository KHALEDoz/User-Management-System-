# User Management System

A complete web application built with HTML, CSS, JavaScript, and PHP that allows you to manage user records with a MySQL database.

## Features

- ✅ One-line form with name, age, and submit button
- ✅ MySQL database integration for data storage
- ✅ Display all records in a responsive table
- ✅ Toggle button for each record to switch status (0/1)
- ✅ Real-time status updates without page refresh
- ✅ Modern, responsive design
- ✅ Input validation and error handling
- ✅ XSS protection and SQL injection prevention

## Prerequisites

Before running this application, make sure you have:

1. **Web Server** (Apache, Nginx, or built-in PHP server)
2. **PHP** (version 7.4 or higher)
3. **MySQL** (version 5.7 or higher)
4. **PHP PDO Extension** (for database connectivity)

## Installation

### 1. Clone or Download Files
Place all files in your web server directory.

### 2. Configure Database
Edit the `config.php` file and update the database credentials:

```php
define('DB_HOST', 'localhost');     // Your MySQL host
define('DB_USER', 'root');         // Your MySQL username
define('DB_PASS', '');             // Your MySQL password
define('DB_NAME', 'user_management'); // Database name (will be created automatically)
```

### 3. Start Web Server

#### Option A: Using PHP Built-in Server
```bash
php -S localhost:8000
```

#### Option B: Using Apache/Nginx
Place files in your web server's document root (e.g., `/var/www/html/` on Linux or `htdocs/` on XAMPP).

### 4. Access the Application
Open your browser and navigate to:
- If using PHP server: `http://localhost:8000`
- If using Apache/Nginx: `http://localhost/your-project-folder`

## File Structure

```
├── index.html          # Main HTML page
├── style.css           # CSS styling
├── script.js           # JavaScript functionality
├── config.php          # Database configuration
├── add_user.php        # Handle user addition
├── get_users.php       # Retrieve users
├── toggle_status.php   # Handle status toggle
└── README.md           # This file
```

## Database Schema

The application automatically creates a `users` table with the following structure:

```sql
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    age INT NOT NULL,
    status TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## Usage

1. **Add Users**: Fill in the name and age fields, then click "Add User"
2. **View Records**: All users are displayed in the table below the form
3. **Toggle Status**: Click the "Activate" or "Deactivate" button to change user status
4. **Real-time Updates**: Status changes are reflected immediately without page refresh

## Security Features

- **SQL Injection Prevention**: Uses prepared statements
- **XSS Protection**: Input sanitization and output escaping
- **Input Validation**: Server-side validation for all inputs
- **Error Handling**: Comprehensive error handling and logging

## Browser Compatibility

- Chrome (recommended)
- Firefox
- Safari
- Edge

## Troubleshooting

### Common Issues

1. **Database Connection Error**
   - Check your MySQL credentials in `config.php`
   - Ensure MySQL service is running
   - Verify PHP PDO extension is installed

2. **Permission Denied**
   - Ensure web server has read/write permissions to the project directory
   - Check file permissions (644 for files, 755 for directories)

3. **Page Not Loading**
   - Verify web server is running
   - Check if PHP is properly configured
   - Look for syntax errors in browser console

### Error Logs

Check your web server's error logs for detailed error messages:
- Apache: `/var/log/apache2/error.log`
- Nginx: `/var/log/nginx/error.log`
- PHP: Check your `php.ini` error log setting

## Customization

### Styling
Modify `style.css` to change the appearance of the application.

### Database
Edit `config.php` to change database settings or add additional fields to the users table.

### Functionality
Extend `script.js` and the PHP files to add new features like:
- User editing
- User deletion
- Search functionality
- Pagination
- Export to CSV/PDF

## License

This project is open source and available under the MIT License.

## Support

If you encounter any issues or have questions, please check the troubleshooting section above or create an issue in the project repository. 